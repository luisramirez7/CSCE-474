1. Luis Ramirez
2. Unzip the folder, run the `make` command, and execute using ./myThread
3. The assignment took me between about 6-12 hours
4. 5 tasks completed - each task took about 1.5-2 hours
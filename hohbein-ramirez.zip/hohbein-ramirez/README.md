Running on cse: 

To run the apriori algorithm:
python3 apriori.py <min_support> <min_confidence>
import os
import pandas as pd
import sys
from scipy.io import arff
from collections import OrderedDict
import itertools
import matplotlib
matplotlib.use("TkAgg")
import matplotlib.pyplot as plt
import time


DATA = 'vote.arff'

data = arff.loadarff(DATA)
df = pd.DataFrame(data[0])

# Decode the data from its binary representation
# To a string representation
for column in df:
    df[column] = df[column].str.decode(encoding='utf-8')

# Get dummies to help with math
# in the C k tables
df = pd.get_dummies(df)

# Cast the whole data set to int type
# so that we can do math with it
for column in df:
    df[column] = df[column].astype(int)


def filter_candidates(bill_combinations, votes_for_bill, voters):
    # Counter that returns the total support for bill combinations
    total_bill_support = 0
    # Number of sets that we are looking at
    number_of_sets = len(bill_combinations)
    for voter in range(voters):
        # Write place holder list of "NO" votes
        # To set the initial support tracker
        # For as many items that are contained in a set
        total_bills = list()
        total_bills = [0] * number_of_sets

        # For as many items there are in the candidate set
        # Look at how many people supported the bill.
        for item in range(number_of_sets):
            # Set the value of votes for bill cast to the bill in question
            bill_in_question = votes_for_bill[bill_combinations[item]]
            if(bill_in_question[voter] == 1):
                total_bills[item] = 1

        # Keep a count of how many times the bill 
        # Was supported
        bill_supported = 0

        for bill in range(number_of_sets):
            if (total_bills[bill] == 1):
                bill_supported += 1
        # IF the bill was supported enough times
        # to meet the condition than we have enough 
        # Support for both bills
        # And so add to the total support for the bill
        if(bill_supported == number_of_sets):
            total_bill_support += 1

    return total_bill_support


def generate_l_1(data, min_support):
    l_1 = {}
    for i in data:
        # Count the number of times that the bill was supported
        support_value = data[i].sum()

        # If the support value is greater than the min_support
        # write it out to l_1
        if(support_value >= min_support):
            l_1[i] = support_value

    return l_1


def votes(bill, data):
    column = list(data[bill].values)
    return column


def apriori(data, min_support, confidence):
    # Create the itemset l
    l = []
    # Create the candidate hashable set
    l_k = {}
    # Votes hashable
    k = {}
    # Create the initial itemset table
    l_1 = generate_l_1(data, float(min_support))
    # Get all the bills with min_support
    bills_with_support = []

    for key, value in l_1.items():
        bills_with_support.append(key)

    votes_for_bill = {}

    for i in bills_with_support:
        # Find out how each congressman voted
        votes_for_bill[i] = votes(i, data)

    c_k = list(itertools.combinations(bills_with_support, 2))

    l = list(l_k)
    while(len(l_1) > 1):
        # L_k dictionary to write to
        l_k = {}
        for bill_combinations in c_k:
            # Find the support for the combination of bills
            votes_for = filter_candidates(bill_combinations, votes_for_bill, 435)
            if votes_for >= float(min_support):
                # If the support forç the combination passes
                # Set the key of the dictionary to the combination of bills
                # and the value the support value for that combination of bills
                l_k[bill_combinations] = votes_for
                k[bill_combinations] = votes_for
        
        # frequent_itemset = l_k
        # unique_items = []
        # frequent_set_size = len(frequent_itemset)
        # frequent_itemset_keys = frequent_itemset.keys()
        # frequent_itemset_combinations = itertools.combinations(frequent_itemset_keys, 2)
        print(l_k)
    return l_k

def calc_confidence(rule, frequent_itemsets, itemset):
    union = frequent_itemsets[len(itemset) - 1][itemset]
    frequent_itemset = frequent_itemsets[len(rule) - 1]
    if (rule in frequent_itemset):
        support_from = frequent_itemset[rule]
        confidence = union / support_from
        return confidence


def runtime(data, min_supp, confidence):
    time_tracker = []
    support = 200
    min_support = list(range(support, 435))
    for support in range(support, 435):
            start_time = time.time()
            apriori(data, float(min_supp), float(confidence))
            time_tracker.append(time.time() - start_time)
    fig, ax = plt.subplots()
    ax.set_xlabel('Minimum Support (#)')
    ax.set_ylabel('Runtime of Algorithm (s)')
    ax.set_title('Apriori Algorithm as a Function of Min Support')
    ax.bar(min_support, time_tracker, width=1, align='center')
    plt.show()


# apriori(df, sys.argv[1], sys.argv[2])
runtime(df, .55, .8)